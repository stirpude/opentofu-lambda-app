"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
// Local gateway endpoint (e.g. LocalStack/Floci). When unset, the SDK uses its
// default configuration. AWS Emulator injects the function's role credentials and
// transparently routes AWS SDK calls back to itself, so no endpoint/creds override
// is needed there (and real AWS works the same way).
const ENDPOINT = process.env.AWS_ENDPOINT_URL;
const clientConfig = {
    region: process.env.AWS_REGION || 'us-east-1',
};
if (ENDPOINT) {
    // Explicit local gateway that needs an endpoint + static test credentials.
    clientConfig.endpoint = ENDPOINT;
    clientConfig.credentials = {
        accessKeyId: 'test',
        secretAccessKey: 'test',
    };
}
const dynamoClient = new client_dynamodb_1.DynamoDBClient(clientConfig);
const ENDPOINT_LABEL = ENDPOINT || 'default (emulator/AWS-managed)';
const TABLE_NAME = process.env.TABLE_NAME || 'lambda-test-table';
const handler = async (event) => {
    console.log('Event received:', JSON.stringify(event, null, 2));
    console.log('DynamoDB endpoint:', ENDPOINT_LABEL);
    try {
        const action = event.action || 'put';
        if (action === 'put') {
            return await putItemToDynamoDB(event);
        }
        else if (action === 'scan') {
            return await scanDynamoDB();
        }
        else if (action === 'test') {
            return await testDynamoConnection();
        }
        else {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    error: "Invalid action. Use 'put', 'scan', or 'test'",
                }),
            };
        }
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : String(error),
            }),
        };
    }
};
exports.handler = handler;
async function putItemToDynamoDB(event) {
    const itemId = event.id || `item-${Date.now()}`;
    const itemData = event.data || 'test data from lambda';
    const params = {
        TableName: TABLE_NAME,
        Item: {
            id: { S: itemId },
            timestamp: { S: new Date().toISOString() },
            data: { S: itemData },
            source: { S: 'lambda-emulator' },
        },
    };
    await dynamoClient.send(new client_dynamodb_1.PutItemCommand(params));
    return {
        statusCode: 201,
        body: JSON.stringify({
            message: 'Item successfully written to DynamoDB',
            itemId: itemId,
            timestamp: new Date().toISOString(),
        }),
    };
}
async function scanDynamoDB() {
    const params = {
        TableName: TABLE_NAME,
    };
    const result = await dynamoClient.send(new client_dynamodb_1.ScanCommand(params));
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: 'Successfully scanned DynamoDB table',
            itemCount: result.Items?.length || 0,
            items: result.Items || [],
        }),
    };
}
async function testDynamoConnection() {
    try {
        const params = {
            TableName: TABLE_NAME,
        };
        const result = await dynamoClient.send(new client_dynamodb_1.ScanCommand(params));
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: '✅ Successfully connected to DynamoDB',
                endpoint: ENDPOINT_LABEL,
                table: TABLE_NAME,
                itemCount: result.Items?.length || 0,
                timestamp: new Date().toISOString(),
            }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: '❌ Failed to connect to DynamoDB',
                endpoint: ENDPOINT_LABEL,
                error: error instanceof Error ? error.message : String(error),
            }),
        };
    }
}
//# sourceMappingURL=index.js.map