export declare const handler: (event: any) => Promise<{
    statusCode: number;
    body: string;
}>;
//# sourceMappingURL=index.d.ts.map